<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('timeline_events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('world_id')->constrained()->cascadeOnDelete();
            $table->integer('year');
            $table->string('name');
            $table->longText('description');
            $table->enum('event_type', ['guerra', 'fundacion', 'catastrofe', 'paz', 'descubrimiento', 'traicion', 'alianza'])->default('fundacion');
            $table->enum('importance', ['menor', 'importante', 'crucial'])->default('importante');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('timeline_events');
    }
};
