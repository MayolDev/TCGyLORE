<?php

namespace Database\Seeders;

use App\Models\Card;
use App\Models\Character;
use App\Models\World;
use Illuminate\Database\Seeder;

class CardSeeder extends Seeder
{
    public function run(): void
    {
        $world = World::first();

        // Obtener personajes para asociar algunas cartas
        $elyndra = Character::where('name', 'Elyndra la Sabia')->first();
        $malachar = Character::where('name', 'Malachar el Maldito')->first();
        $sylas = Character::where('name', 'Sylas el Errante')->first();
        $lyra = Character::where('name', 'Lyra Corazón de Tormenta')->first();
        $theron = Character::where('name', 'Theron Puño de Hierro')->first();
        $morgana = Character::where('name', 'Morgana Tejealmas')->first();
        $valorian = Character::where('name', 'Valorian el Justo')->first();

        $cards = [
            [
                'character_id' => $elyndra?->id,
                'name' => 'Elyndra, Fundadora de Lumendor',
                'effect' => '***Entrada al campo:*** Roba 2 cartas.
---
***Habilidad Activada:*** Una vez por turno, puedes buscar un hechizo de Luz en tu mazo y añadirlo a tu mano.
---
"La sabiduría no es poder, es comprensión. Y la comprensión es la verdadera magia."',
                'strength' => 2,
                'agility' => 3,
                'charisma' => 8,
                'mind' => 9,
                'cost' => 7,
                'archetype' => 'Mago',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'luz',
                'rarity' => 'legendaria',
                'faction' => 'Orden de Lumendor',
                'edition' => 'Fundación',
                'artist' => 'María González',
                'flavor_text' => 'La primera y más grande de las archimagas.',
            ],
            [
                'character_id' => $malachar?->id,
                'name' => 'Malachar, Señor de la Oscuridad',
                'effect' => '***Pacto de Sangre:*** Cuando Malachar entre al campo, sacrifica una criatura. Si lo haces, obtiene +5/+5 hasta el fin del turno.
---
***Inmortal:*** Malachar no puede morir en combate. En su lugar, vuelve a tu mano.',
                'strength' => 8,
                'agility' => 4,
                'charisma' => 6,
                'mind' => 7,
                'cost' => 8,
                'archetype' => 'Señor Oscuro',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'oscuridad',
                'rarity' => 'legendaria',
                'faction' => 'Casa Umbravale',
                'edition' => 'Fundación',
                'artist' => 'Carlos Mendoza',
                'flavor_text' => 'El poder tiene un precio. Él ya lo pagó.',
            ],
            [
                'character_id' => $sylas?->id,
                'name' => 'Sylas, El Profeta Errante',
                'effect' => '***Visión de Futuros:*** Mira las 3 primeras cartas de tu mazo. Puedes reorganizarlas en cualquier orden.
---
***Paso Entre Mundos:*** Sylas no puede ser bloqueado.
---
"He visto mil futuros. En ninguno encuentro descanso."',
                'strength' => 3,
                'agility' => 7,
                'charisma' => 5,
                'mind' => 9,
                'cost' => 5,
                'archetype' => 'Errante',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'neutral',
                'rarity' => 'legendaria',
                'faction' => 'Ninguna',
                'edition' => 'Fundación',
                'artist' => 'Ana Rodríguez',
                'flavor_text' => 'Condenado a caminar, destinado a advertir.',
            ],
            [
                'character_id' => $lyra?->id,
                'name' => 'Lyra, Corazón de Tormenta',
                'effect' => '***Invocar Tormenta:*** Todas las criaturas voladoras obtienen +2/+2.
---
***Señora de los Mares:*** Tus criaturas con tipo "Marino" cuestan 2 menos de invocar.',
                'strength' => 6,
                'agility' => 8,
                'charisma' => 7,
                'mind' => 5,
                'cost' => 6,
                'archetype' => 'Pirata',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'neutral',
                'rarity' => 'legendaria',
                'faction' => 'Flota de la Tormenta',
                'edition' => 'Fundación',
                'artist' => 'Pedro Sánchez',
                'flavor_text' => 'El mar es su hogar, la tormenta su aliada.',
            ],
            [
                'character_id' => $theron?->id,
                'name' => 'Theron, Campeón del Coliseo',
                'effect' => '***Golpe Devastador:*** Cuando Theron ataca, puede luchar con una criatura objetivo adicional.
---
***Resistencia Férrea:*** Theron obtiene +1/+1 por cada criatura que controles.',
                'strength' => 9,
                'agility' => 6,
                'charisma' => 7,
                'mind' => 4,
                'cost' => 6,
                'archetype' => 'Guerrero',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'luz',
                'rarity' => 'legendaria',
                'faction' => 'Rebelión de Esclavos',
                'edition' => 'Fundación',
                'artist' => 'Luis Martínez',
                'flavor_text' => 'Cada cicatriz es una victoria. Cada victoria, un paso hacia la libertad.',
            ],
            [
                'name' => 'Rayo de Luz Sagrada',
                'effect' => '***Destruir Oscuridad:*** Destruye una criatura objetivo con alineación Oscuridad.
---
Roba una carta.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 3,
                'archetype' => 'Conjuración',
                'card_type' => 'Hechizo',
                'alignment' => 'luz',
                'rarity' => 'rara',
                'faction' => 'Orden de Lumendor',
                'edition' => 'Fundación',
                'artist' => 'Elena Torres',
                'flavor_text' => 'La luz no conoce sombra que no pueda disipar.',
            ],
            [
                'name' => 'Cosecha de Almas',
                'effect' => '***Sacrificio:*** Sacrifica cualquier número de criaturas que controles. Por cada una, roba una carta y ganas 2 puntos de vida.
---
"Un precio pequeño por poder eterno."',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 5,
                'archetype' => 'Maldición',
                'card_type' => 'Hechizo',
                'alignment' => 'oscuridad',
                'rarity' => 'epica',
                'faction' => 'Casa Umbravale',
                'edition' => 'Fundación',
                'artist' => 'Ricardo Gómez',
                'flavor_text' => 'El alma es solo energía esperando ser aprovechada.',
            ],
            [
                'name' => 'Guardián de Cristal',
                'effect' => '***Defensor:*** Esta criatura debe bloquear si es posible.
---
***Escudo Mágico:*** Previene los primeros 3 puntos de daño que recibiría.',
                'strength' => 4,
                'agility' => 2,
                'charisma' => 1,
                'mind' => 5,
                'cost' => 4,
                'archetype' => 'Constructo',
                'card_type' => 'Criatura',
                'alignment' => 'neutral',
                'rarity' => 'comun',
                'faction' => 'Orden de Lumendor',
                'edition' => 'Fundación',
                'artist' => 'Sofía Ramírez',
                'flavor_text' => 'Los cristales de Aethermoor guardan secretos antiguos.',
            ],
            [
                'name' => 'Lobo Sombrío',
                'effect' => '***Cazador Nocturno:*** Obtiene +2/+0 durante tu turno.
---
***Manada:*** Por cada otro Lobo que controles, esta criatura obtiene +1/+1.',
                'strength' => 3,
                'agility' => 6,
                'charisma' => 2,
                'mind' => 2,
                'cost' => 3,
                'archetype' => 'Bestia',
                'card_type' => 'Criatura',
                'alignment' => 'neutral',
                'rarity' => 'comun',
                'faction' => 'Círculo Druídico',
                'edition' => 'Fundación',
                'artist' => 'Miguel Herrera',
                'flavor_text' => 'El bosque tiene ojos, y todos ellos te observan.',
            ],
            [
                'name' => 'Maremoto',
                'effect' => '***Devastación Marina:*** Destruye todas las criaturas que no sean de tipo Marino.
---
Los jugadores descartan su mano y roban 5 cartas.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 9,
                'archetype' => 'Catástrofe',
                'card_type' => 'Hechizo',
                'alignment' => 'neutral',
                'rarity' => 'epica',
                'faction' => 'Flota de la Tormenta',
                'edition' => 'Fundación',
                'artist' => 'Laura Díaz',
                'flavor_text' => 'Cuando el mar se enfurece, todos somos iguales ante su poder.',
            ],
            [
                'name' => 'Espada Sagrada de Valorian',
                'effect' => '***Equipar (3):*** La criatura equipada obtiene +4/+2 y gana ***Golpe Primero***.
---
Si la criatura equipada tiene alineación Luz, destruye una criatura objetivo de alineación Oscuridad cuando ataque.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 5,
                'archetype' => 'Reliquia',
                'card_type' => 'Artefacto - Equipo',
                'alignment' => 'luz',
                'rarity' => 'epica',
                'faction' => 'Orden de la Luz Sagrada',
                'edition' => 'Fundación',
                'artist' => 'Javier López',
                'flavor_text' => 'Forjada con fe, templada con justicia.',
            ],
            [
                'name' => 'Orbe de los Mil Caminos',
                'effect' => '***Legendario***
---
Al comienzo de tu turno, mira la carta superior de tu mazo. Puedes ponerla en el fondo.
---
***Sacrificar el Orbe:*** Toma un turno extra después de este. Juega esta habilidad solo si controlas a Sylas.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 6,
                'archetype' => 'Reliquia',
                'card_type' => 'Artefacto Legendario',
                'alignment' => 'neutral',
                'rarity' => 'legendaria',
                'faction' => 'Ninguna',
                'edition' => 'Fundación',
                'artist' => 'Carmen Ruiz',
                'flavor_text' => 'Ver todos los futuros es no vivir ninguno.',
            ],
            [
                'name' => 'Grieta Eterna',
                'effect' => '***Tierra Legendaria***
---
Añade 1 maná oscuro a tu reserva.
---
***Sacrificar la Grieta:*** Invoca una criatura Demonio de tu mano sin pagar su coste.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 0,
                'archetype' => 'Tierra',
                'card_type' => 'Tierra Legendaria',
                'alignment' => 'oscuridad',
                'rarity' => 'epica',
                'faction' => 'Ninguna',
                'edition' => 'Fundación',
                'artist' => 'Daniel Castro',
                'flavor_text' => 'Una herida en el mundo que nunca sanará.',
            ],
            [
                'name' => 'Titán de Roca Despertado',
                'effect' => '***Despertar Legendario:*** No puede ser invocado antes del turno 10.
---
***Indestructible***
---
***Pisotón:*** Cuando ataca, destruye todas las criaturas bloqueadoras con fuerza 4 o menos.',
                'strength' => 12,
                'agility' => 1,
                'charisma' => 3,
                'mind' => 8,
                'cost' => 12,
                'archetype' => 'Titán',
                'card_type' => 'Criatura Legendaria',
                'alignment' => 'neutral',
                'rarity' => 'legendaria',
                'faction' => 'Ninguna',
                'edition' => 'Fundación',
                'artist' => 'Fernando Silva',
                'flavor_text' => 'Cuando las montañas caminan, el mundo tiembla.',
            ],
            [
                'name' => 'Destello de Tormenta',
                'effect' => '***Instantáneo***
---
Hace 3 de daño a una criatura o jugador objetivo.
---
Si controlas a Lyra, hace 5 de daño en su lugar y roba una carta.',
                'strength' => null,
                'agility' => null,
                'charisma' => null,
                'mind' => null,
                'cost' => 2,
                'archetype' => 'Conjuración',
                'card_type' => 'Hechizo Instantáneo',
                'alignment' => 'neutral',
                'rarity' => 'comun',
                'faction' => 'Flota de la Tormenta',
                'edition' => 'Fundación',
                'artist' => 'Patricia Morales',
                'flavor_text' => 'Un relámpago, un trueno, y el enemigo ya no está.',
            ],
        ];

        foreach ($cards as $card) {
            Card::create(array_merge($card, ['world_id' => $world->id]));
        }
    }
}
