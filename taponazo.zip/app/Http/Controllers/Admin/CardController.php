<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Card;
use App\Models\Character;
use App\Models\World;
use Illuminate\Http\Request;
use Inertia\Inertia;

class CardController extends Controller
{
    public function index(Request $request)
    {
        $cards = Card::query()
            ->with(['world', 'character'])
            ->when($request->input('search'), function ($query, $search) {
                $query->where('name', 'like', "%{$search}%");
            })
            ->when($request->input('rarity'), function ($query, $rarity) {
                $query->where('rarity', $rarity);
            })
            ->when($request->input('card_type'), function ($query, $type) {
                $query->where('card_type', $type);
            })
            ->when($request->input('alignment'), function ($query, $alignment) {
                $query->where('alignment', $alignment);
            })
            ->when($request->input('world_id'), function ($query, $worldId) {
                $query->where('world_id', $worldId);
            })
            ->latest()
            ->paginate(12)
            ->withQueryString();

        return Inertia::render('Admin/Cards/Index', [
            'cards' => $cards,
            'worlds' => World::all(['id', 'name']),
            'filters' => $request->only(['search', 'rarity', 'card_type', 'alignment', 'world_id']),
        ]);
    }

    public function create()
    {
        return Inertia::render('Admin/Cards/Create', [
            'worlds' => World::all(['id', 'name']),
            'characters' => Character::all(['id', 'name']),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'world_id' => ['required', 'exists:worlds,id'],
            'character_id' => ['nullable', 'exists:characters,id'],
            'name' => ['required', 'string', 'max:255'],
            'illustration' => ['nullable', 'string'],
            'effect' => ['required', 'string'],
            'strength' => ['nullable', 'integer', 'min:0', 'max:20'],
            'agility' => ['nullable', 'integer', 'min:0', 'max:20'],
            'charisma' => ['nullable', 'integer', 'min:0', 'max:20'],
            'mind' => ['nullable', 'integer', 'min:0', 'max:20'],
            'cost' => ['required', 'integer', 'min:0'],
            'archetype' => ['required', 'string', 'max:255'],
            'card_type' => ['required', 'string', 'max:255'],
            'alignment' => ['required', 'in:luz,oscuridad,neutral'],
            'rarity' => ['required', 'in:comun,rara,epica,legendaria'],
            'faction' => ['nullable', 'string', 'max:255'],
            'edition' => ['nullable', 'string', 'max:255'],
            'artist' => ['nullable', 'string', 'max:255'],
            'flavor_text' => ['nullable', 'string'],
        ]);

        Card::create($validated);

        return redirect()->route('admin.cards.index')
            ->with('success', 'Carta creada exitosamente.');
    }

    public function edit(Card $card)
    {
        $card->load(['world', 'character']);

        return Inertia::render('Admin/Cards/Edit', [
            'card' => $card,
            'worlds' => World::all(['id', 'name']),
            'characters' => Character::all(['id', 'name']),
        ]);
    }

    public function update(Request $request, Card $card)
    {
        $validated = $request->validate([
            'world_id' => ['required', 'exists:worlds,id'],
            'character_id' => ['nullable', 'exists:characters,id'],
            'name' => ['required', 'string', 'max:255'],
            'illustration' => ['nullable', 'string'],
            'effect' => ['required', 'string'],
            'strength' => ['nullable', 'integer', 'min:0', 'max:20'],
            'agility' => ['nullable', 'integer', 'min:0', 'max:20'],
            'charisma' => ['nullable', 'integer', 'min:0', 'max:20'],
            'mind' => ['nullable', 'integer', 'min:0', 'max:20'],
            'cost' => ['required', 'integer', 'min:0'],
            'archetype' => ['required', 'string', 'max:255'],
            'card_type' => ['required', 'string', 'max:255'],
            'alignment' => ['required', 'in:luz,oscuridad,neutral'],
            'rarity' => ['required', 'in:comun,rara,epica,legendaria'],
            'faction' => ['nullable', 'string', 'max:255'],
            'edition' => ['nullable', 'string', 'max:255'],
            'artist' => ['nullable', 'string', 'max:255'],
            'flavor_text' => ['nullable', 'string'],
        ]);

        $card->update($validated);

        return redirect()->route('admin.cards.index')
            ->with('success', 'Carta actualizada exitosamente.');
    }

    public function destroy(Card $card)
    {
        $card->delete();

        return redirect()->route('admin.cards.index')
            ->with('success', 'Carta eliminada exitosamente.');
    }
}
