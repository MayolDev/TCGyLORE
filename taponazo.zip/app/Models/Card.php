<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Card extends Model
{
    use HasFactory;

    protected $fillable = [
        'world_id',
        'character_id',
        'name',
        'illustration',
        'effect',
        'strength',
        'agility',
        'charisma',
        'mind',
        'cost',
        'archetype',
        'card_type',
        'alignment',
        'rarity',
        'faction',
        'edition',
        'artist',
        'flavor_text',
    ];

    protected function casts(): array
    {
        return [
            'strength' => 'integer',
            'agility' => 'integer',
            'charisma' => 'integer',
            'mind' => 'integer',
            'cost' => 'integer',
        ];
    }

    public function world(): BelongsTo
    {
        return $this->belongsTo(World::class);
    }

    public function character(): BelongsTo
    {
        return $this->belongsTo(Character::class);
    }

    public function getFormattedEffectAttribute(): string
    {
        $text = $this->effect;

        // Convertir ***texto*** a <strong>texto</strong>
        $text = preg_replace('/\*\*\*(.*?)\*\*\*/', '<strong>$1</strong>', $text);

        // Convertir --- a <hr>
        $text = str_replace('---', '<hr class="my-2">', $text);

        return $text;
    }
}
